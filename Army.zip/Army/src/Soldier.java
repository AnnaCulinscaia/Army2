public class Soldier extends Creature implements Walking{
    public void Walk(){

    }

    public void SoldierInfo(){
        System.out.println("Name = "+this.name+" HP "+this.hitPoints+" Melle Damage "+this.melleDamage);
    }

}
