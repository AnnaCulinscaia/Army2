import java.util.Scanner;

public class Main extends Creature{

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the name of the soldier ");
        String name = scanner.nextLine();
        System.out.println("Enter the melee- damage ");
        int melleDamage = scanner.nextInt();
        System.out.println("Enter hit points");
        int hitPoints = scanner.nextInt();
        System.out.println("Enter the number of soldiers");
        AllySoldier allySoldier= new AllySoldier("Soldier", melleDamage, hitPoints );
        EnemySoldier enemySoldier = new EnemySoldier("Pavel", 170, 170);
        AllyCommander allyCommander = new AllyCommander("Augustin", 175, 185);
        AllyDragon allyDragon = new AllyDragon("Kin", 789, 568);
        EnemyCommander enemyCommander = new EnemyCommander("Teo", 745, 987);
        EnemyDragon enemyDragon = new EnemyDragon("Lon", 784, 898);
        Mage mage = new Mage("Joy", 7878, 4560, 78);
        Witch witch = new Witch("Grace", 78523, 78945612, 4564);

//        allySoldier.SoldierInfo();
//        enemySoldier.SoldierInfo();
//        allySoldier.Walk();
//        enemySoldier.Walk();
//        allySoldier.Protect();
//        witch.Curse();
//        enemyDragon.Fly();
//        allyDragon.Fly();
//        String unitName;
//        switch( unitName ){
//            case "AllySoldier" :
//
//                System.out.println("Enter the melee- damage ");
//                int melleDamage = scanner.nextInt();
//                System.out.println("Enter hit points");
//                int hitPoints = scanner.nextInt();
//                System.out.println("Enter the number of soldiers");
//                int numberOfSoldiers = scanner.nextInt();
//
//                break;
//            case "EnemySoldier":
//                System.out.println("Enter the melee- damage ");
//                int melleDamage = scanner.nextInt();
//                System.out.println("Enter hit points");
//                int hitPoints = scanner.nextInt();
//                System.out.println("Enter the number of soldiers");
//                int numberOfSoldiers = scanner.nextInt();
//                EnemySoldier[]  enemySoldier = new EnemySoldier[numberOfSoldiers];
//                for (int i = 1; i<= numberOfSoldiers; i++) {
//                    enemySoldier[i]= new EnemySoldier("Soldier"+i, melleDamage, hitPoints );
//                }
//
//
//
//        }





    }

