public class EnemyDragon extends Dragon{
    @Override
    public void Attack() {
        System.out.println(" Enemy Dragon is attacking ");
    }
    public EnemyDragon(String name, int melleDamage, int hitPoints ){
        setName (name);
        setMelleDamage(melleDamage);
        setHp(hitPoints);
    }
    @Override
    public void Fly(){
        System.out.println("Enemy Dragon is flying");
    }
}
