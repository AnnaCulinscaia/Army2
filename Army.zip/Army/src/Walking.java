public interface Walking {
    void Walk();
    int distance = 0;
}
