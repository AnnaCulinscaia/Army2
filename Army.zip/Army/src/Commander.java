public class Commander extends Creature implements Commanding {
    public void SendAttackOrders(){
        System.out.println("The Commander is sending the orders");
    }
}
