public interface BlackMagic  {
    void Curse();

}
