public interface Defending {
    void Protect();
    float shieldCapacity = 0;
}
