public class Sorcerer extends Creature {
    private float spellDamage;
    public void SorcererInfo(){
        System.out.println("Name = "+this.name+" HP "+this.hitPoints+" Melle Damage "+this.melleDamage);
    }

}
