public class AllyDragon extends Dragon{
    @Override
    public void Attack() {
        System.out.println(" Ally Dragon is attacking ");
    }
    public AllyDragon(String name, int melleDamage, int hitPoints ){
        setName (name);
        setMelleDamage(melleDamage);
        setHp(hitPoints);
    }
    @Override
    public void Fly(){
        System.out.println("Ally Dragon is flying");
    }
}
