public class Dragon extends Creature implements Flying {
    public void Fly(){
        System.out.println("The Dragon is flyings");
    }
    public void DragonInfo(){
        System.out.println("Name = "+this.name+" HP "+this.hitPoints+" Melle Damage "+this.melleDamage);
    }
}
