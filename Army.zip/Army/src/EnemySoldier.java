public class EnemySoldier extends Soldier{
    @Override
    public void Attack() {
        System.out.println(" Enemy Soldier is attacking ");
    }

    public EnemySoldier(String name, int melleDamage, int hitPoints ){
        setName (name);
        setMelleDamage(melleDamage);
        setHp(hitPoints);
    }
    @Override
    public void Walk(){

        System.out.println("An EnemySoldier is Walking");
    }

}
