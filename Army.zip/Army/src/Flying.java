public interface Flying {
    void Fly();
}
