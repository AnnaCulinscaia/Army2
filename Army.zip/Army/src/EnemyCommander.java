public class EnemyCommander extends Commander {
    @Override
    public void SendAttackOrders(){
        System.out.println("The Enemy Commander is sending orders");
    }
    public EnemyCommander(String name, int melleDamage, int hitPoints ){
        setName (name);
        setMelleDamage(melleDamage);
        setHp(hitPoints);
    }
}
