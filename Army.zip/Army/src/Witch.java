public class Witch extends Sorcerer implements BlackMagic {
    public void Curse(){
        System.out.println("Witch Curse");

    }
    @Override
    public void Attack() {
        System.out.println(" Witch  is attacking ");
    }

    public Witch(String name, int spellDamage, int hitPoints,int manaPoints){
        setName (name);
        setMelleDamage(melleDamage);
        setHp(hitPoints);
        setManaPoints(manaPoints);
    }

}
