public interface Commanding {
    void SendAttackOrders();
}
