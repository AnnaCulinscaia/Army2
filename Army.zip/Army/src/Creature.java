public class Creature {
protected int hitPoints;
protected int manaPoints;
protected int Stamina;
protected int melleDamage;

//Races
    protected enum Race{
        Elve, Human, Dvarf, Ork, Halfing, Mudblood
}
    public int getManaPoins() {
        return manaPoints;
    }

    public void setManaPoints(int manaPoints) {
        manaPoints = manaPoints;
    }

    public int getStamina() {
        return Stamina;
    }

    public void setStamina(int stamina) {
        Stamina = stamina;
    }

    String name;

    public  void Attack() {
        System.out.println("Attack");
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMelleDamage() {
        return melleDamage;
    }

    public void setMelleDamage(int melleDamage) {
        this.melleDamage = melleDamage;
    }


    public int getHp() {
        return hitPoints;
    }

    public void setHp(int hitPoints) {
        this.hitPoints = hitPoints;
    }



}

