public class AllyCommander extends Creature implements Commanding{
    @Override
    public void SendAttackOrders(){
        System.out.println("The Ally Commander is sending orders");
    }
    public AllyCommander(String name, int melleDamage, int hitPoints ){
        setName (name);
        setMelleDamage(melleDamage);
        setHp(hitPoints);
    }

}
