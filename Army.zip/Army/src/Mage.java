public class Mage extends Sorcerer implements WhiteMagic{
    public void CastSpell(){
        System.out.println("Casting the Spell");
    }

    @Override
    public void Attack() {
        System.out.println(" Mage is attacking ");
    }

    public Mage(String name, int spellDamage, int hitPoints,int manaPoints){
        setName (name);
        setMelleDamage(melleDamage);
        setHp(hitPoints);
        setManaPoints(manaPoints);
    }
}
