public interface WhiteMagic {
    public void CastSpell();

}
