    import java.util.*;
    import java.util.Scanner;
    public class AllySoldier extends Soldier implements Defending, Walking{
@Override
    public void Walk(){

        System.out.println("An AllySoldier is Walking");
    }

    public void Protect()
    {
        System.out.println("Shields up!");
    }
    @Override
    public void Attack() {
        System.out.println("Ally Soldier is attacking ");


    }

Race race;
AllySoldier allySoldier = new AllySoldier("all", 20, 20, race.Ork);
public void raceOut(){
    switch (race) {
        case Ork: {
            System.out.println("ORK");

        } break;
    }
}

    public AllySoldier(String name, int melleDamage, int hitPoints, Race race ){
        setName (name);
        setMelleDamage(melleDamage);
        setHp(hitPoints);
    }


}
